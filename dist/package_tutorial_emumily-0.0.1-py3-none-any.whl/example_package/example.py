"""
simple functions for a simple package
"""

def add_one(number):
    return number + 1

def hell(f, u):
    print(f, "says hello", i, "...")
    
